package io.median.android;

public class HelperClass {
    public volatile static int newLoad = 0;
}
