
function convertEnglishToNagriRealtime(direction) {
    const engToNagriMap = {
        'a': 'ꠣ', 'aa': 'ꠀ', 'i': 'ꠤ', 'ii': 'ꠤ', 'u': 'ꠥ', 'uu': 'ꠥ',
        'e': 'ꠦ', 'oi': 'ꠅꠁ', 'o': 'ꠣ', 'ou': 'ꠅꠃ',
        'ri': 'ꠞꠤ',
        'k': 'ꠇ', 'kh': 'ꠈ', 'g': 'ꠉ', 'gh': 'ꠊ', 'ng': 'ꠋ',
        'c': 'ꠌ', 'ch': 'ꠌ', 'chh': 'ꠍ', 'j': 'ꠎ', 'jh': 'ꠏ',
        't': 'ꠔ', 'th': 'ꠕ', 'd': 'ꠖ', 'dh': 'ꠗ', 'n': 'ꠘ',
        'p': 'ꠙ', 'ph': 'ꠚ', 'b': 'ꠛ', 'bh': 'ꠜ', 'm': 'ꠝ',
        'z': 'ꠎ', 'y': 'ꠁ', 'r': 'ꠞ', 'l': 'ꠟ', 'sh': 'ꠡ', 's': 'ꠡ',
        'h': 'ꠢ', 'rr': 'ꠠ', 'rh': 'ꠠ',
        'ং': 'ꠋ', 'ঃ': 'ꠂ', 'ঁ': 'ꠘ', '.': '*', ' ': ' '
        };

    const nagriToEngMap = {};
    for (const [eng, nag] of Object.entries(engToNagriMap)) {
        nagriToEngMap[nag] = eng;
    }

    let inputText = '';
    let output = '';
    if (direction === 'english') {
        inputText = document.getElementById("englishInput").value.toLowerCase();
        let i = 0;
        while (i < inputText.length) {
            let match = '';
            for (let len = 3; len > 0; len--) {
                const chunk = inputText.substr(i, len);
                if (engToNagriMap[chunk]) {
                    match = engToNagriMap[chunk];
                    i += len;
                    break;
                }
            }
            output += match || inputText[i++];
        }
        document.getElementById("nagriOutput").value = output;
    } else {
        inputText = document.getElementById("nagriOutput").value;
        for (let char of inputText) {
            output += nagriToEngMap[char] || char;
        }
        document.getElementById("englishInput").value = output;
    }
}



function copyText(id, btn) {
    const textArea = document.getElementById(id);
    textArea.select();
    textArea.setSelectionRange(0, 99999); // Mobile support
    document.execCommand("copy");
    btn.innerHTML = '<i class="bi bi-check-lg me-1"></i> কপি হয়েছে';
    setTimeout(() => {
        btn.innerHTML = '<i class="bi bi-clipboard me-1"></i> কপি';
    }, 2000);
}

function clearText(id) {
    document.getElementById(id).value = '';
}
    